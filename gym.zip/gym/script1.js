
// Move exercise cards to the Exercises section
const exercisesContainer = document.querySelector('#Exercises');
const exerciseCards = document.querySelectorAll('.exercise-card');

exerciseCards.forEach(card => {
    exercisesContainer.appendChild(card);
});

 const toggleButton = document.querySelector('#toggleExercises');
 
 toggleButton.addEventListener('click', () => {
     exercisesContainer.classList.toggle('visible');
 });
