const exerciseDetails = {
    'bench-press': {
        title: 'Bench Press',
        description: 'The bench press is a compound exercise that primarily targets the chest muscles. Lie on a bench, grip the barbell, and lower it to your chest before pushing it back up.'
    },
    'bicep-curl': {
        title: 'Bicep Curl',
        description: 'The bicep curl is an isolation exercise that targets the biceps. Hold a dumbbell in each hand, curl the weights toward your shoulders while keeping your elbows stable.'
    },
    'overhead-press': {
        title: 'Overhead Press',
        description: 'The overhead press, also known as the shoulder press, targets the shoulder muscles. Lift a barbell or dumbbells from shoulder height to overhead while keeping your core engaged.'
    },
    'deadlift': {
        title: 'Deadlift',
        description: 'The deadlift is a compound exercise that primarily targets the back muscles. Lift a barbell or weights from the ground to a standing position, engaging your back and legs.'
    },
    'leg-press':{
        title:'Leg Press',
        description:'The leg press targets the quadriceps muscles in the front of the thighs, the gluteal muscles in the buttocks, the hamstring muscles in the back of the thighs, and the calves.'
    },
    'DumbBell':{
        title:'DumbBell Bench Press',
        description:'The incline dumbbell press is another variation of the incline barbell bench press that targets similar muscle groups.'
    },
    'pushup':{
        title:"PushUp",
        description:'The push-up is a common calisthenics exercise beginning from the prone position.By raising and lowering the body using the arms, push-ups exercise the pectoral muscles, triceps,and coracobrachialis and the midsection as a whole.'
    },
    'triceps extension':{
        title : "Triceps Extension",
        description:'The triceps extension is an isolation exercise that works the muscle on the back of the upper arm.Begin standing with your feet in a slight split stance, with the left foot just slightly behind the right and the legs about hips distance apart.'
    },
    'pullup':{
        title :"Pull Up" ,
        description:'A pull-up is an upper-body strength exercise. The pull-up is a closed-chain movement where the body is suspended by the hands, gripping a bar or other implement at a distance typically wider than shoulder-width, and pulled up.'
    }
};

const exerciseList = document.getElementById('exercise-list');
const homeButton = document.getElementById('home-button');
const exerciseSections = document.querySelectorAll('.exercise-group');
const exerciseLinks = document.querySelectorAll('.exercise-link');

homeButton.addEventListener('click', () => {
    exerciseList.style.display = 'block';
    overlay.style.display = 'none';
    
});



exerciseLinks.forEach(link => {
    link.addEventListener('click', () => {
        const targetSectionId = link.getAttribute('data-target');
        
        exerciseSections.forEach(section => {
            if (section.id === targetSectionId) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });

        exerciseList.style.display = 'none';
    });
});


const exerciseButtons = document.querySelectorAll('.exercise-details-button');
const overlay = document.getElementById('exercise-details-overlay');
const titleElement = document.getElementById('exercise-details-title');
const descriptionElement = document.getElementById('exercise-details-description');
const closeButton = document.getElementById('close-exercise-details');

exerciseButtons.forEach(button => {
    button.addEventListener('click', () => {
        const exerciseKey = button.getAttribute('data-exercise');
        const exercise = exerciseDetails[exerciseKey];
        
        if (exercise) {
            titleElement.textContent = exercise.title;
            descriptionElement.textContent = exercise.description;
            overlay.style.display = 'flex';
        }
    });
});

closeButton.addEventListener('click', () => {
    overlay.style.display = 'none';
});

// ... Previous JavaScript code ...

const signupSection = document.querySelector('.signup-section');
const contactSection = document.querySelector('.contact-section');
const exerciseDetailsSections = document.querySelectorAll('.exercise-details');

exerciseLinks.forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault(); // Prevent default navigation behavior
        const targetSectionId = link.getAttribute('data-target');

        exerciseDetailsSections.forEach(section => {
            if (section.id === targetSectionId) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });

        signupSection.style.display = 'none';
        contactSection.style.display = 'none';
    });
});

// ... Previous JavaScript code ...

const signupForm = document.getElementById('signup-form');

signupForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent form submission
    
    // Get form values
    const name = signupForm.querySelector('#name').value;
    const email = signupForm.querySelector('#email').value;
    const password = signupForm.querySelector('#password').value;
    
    // You can perform further processing, validation, and submit data to a server here
    
    // For this example, we'll just log the form data
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Password:', password);
    
    // Clear form fields
    signupForm.reset();
});


signupForm.addEventListener('focus', () => {
    signupSection.classList.add('form-visible');
}, true);

// Remove the class when the form loses focus
signupForm.addEventListener('blur', () => {
    signupSection.classList.remove('form-visible');
}, true);

signupForm.addEventListener('submit', (event) => {
    // ... Previous submit logic ...
});
exerciseLinks.forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault(); // Prevent default navigation behavior
        const targetSectionId = link.getAttribute('data-target');              
        exerciseSections.forEach(section => {
            if (section.id === targetSectionId) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';

            }
        });
    });
});