<div class="logo">
        <img src="./images/fitnesss.png"/>
    </div>
    <section >
        <img src="images\fitnessscreenshot.png"/>
        </section>
        <main style="margin: auto;">
            <p>Welcome to Fitness! We are a fitness company that offers various types of workouts for you.</p>
            *{
    margin: 0%;
    padding: 0%;
    box-sizing: border-box;
}
.container{
    width :1280px ;
    height: auto;
    background:#fff url(bg.jpg) no-repeat center top / cover;
    display: flex;
    justify-content: space-between;
    }
.logo {
        position: relative;
        z-index:354679;
        float: left;
        font-size: xx-large;
        color: #ffffff;
        text-transform: uppercase;
        letter-spacing:-1px;
        line-height: normal;
        word-wrap: break-word;
        overflow: hidden;
        white-space: nowrap;
        max-width: none !important;}
        
            /* Add CSS styles to align the navigation items horizontally */
.navigation {
                list-style: none;
                padding: 0;
                margin: 0;
                display: flex;
                align-items: center;
            }
            <section>
            <div class="Exercises" id="AvaliableExercises">
                <table border="3px solid black"; align ="center"; width="50%">
                    <tr bgcolor="grey">
                        <th colspan="4">
                            Available Exercises
                                 </th> </tr>
                                 <tr><td>Cardio</td></tr>
                                 <tr><td>Weight Lifting</td></tr>  
